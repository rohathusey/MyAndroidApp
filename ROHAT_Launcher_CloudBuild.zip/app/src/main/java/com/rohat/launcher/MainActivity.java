package com.rohat.launcher;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, grid;
    EditText search;
    TextView greeting, timeText, weatherText, brand;
    int gold = Color.rgb(244,163,58), bg = Color.rgb(7,16,27);
    String lang = "ar";
    ArrayList<AppInfo> apps = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        build();
        loadApps();
        updateTime();
    }

    GradientDrawable bg(int color, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(r); return d;
    }

    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }

    void build() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(8));
        root.setBackgroundColor(bg);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        brand = tv("♛  ROHAT", 22, gold); brand.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button langBtn = new Button(this); langBtn.setText("AR");
        langBtn.setTextColor(Color.WHITE); langBtn.setBackground(bg(Color.rgb(28,42,60),40));
        langBtn.setOnClickListener(v -> { lang = lang.equals("ar") ? "tr" : lang.equals("tr") ? "en" : "ar"; langBtn.setText(lang.toUpperCase()); refreshLabels(); });
        top.addView(langBtn, new LinearLayout.LayoutParams(dp(58), dp(42)));
        root.addView(top);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18),dp(12),dp(18),dp(12)); hero.setBackground(bg(Color.rgb(18,31,50),34));
        greeting = tv("أهلاً في ROHAT", 25, Color.WHITE); greeting.setTypeface(Typeface.DEFAULT_BOLD);
        hero.addView(greeting);
        LinearLayout row = new LinearLayout(this);
        timeText = tv("", 34, Color.WHITE); timeText.setTypeface(Typeface.DEFAULT_BOLD);
        weatherText = tv("☁  24°", 16, Color.LTGRAY);
        row.addView(timeText, new LinearLayout.LayoutParams(0,dp(52),1));
        row.addView(weatherText, new LinearLayout.LayoutParams(dp(90),dp(52)));
        hero.addView(row);
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(118)));

        search = new EditText(this); search.setSingleLine(true); search.setHint("ابحث عن تطبيق...");
        search.setTextColor(Color.WHITE); search.setHintTextColor(Color.rgb(150,160,175));
        search.setPadding(dp(18),0,dp(18),0); search.setBackground(bg(Color.rgb(25,39,58),40));
        search.addTextChangedListener(new android.text.TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ render(s.toString()); }
            public void afterTextChanged(android.text.Editable e){}
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,dp(52)); sp.setMargins(0,dp(12),0,dp(10));
        root.addView(search,sp);

        ScrollView scroll = new ScrollView(this);
        grid = new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(grid);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));

        TextView hint = tv("🧶  أيقونات ROHAT بتأثير الصوف  •  أنمي  •  3D",13,Color.rgb(180,188,198));
        hint.setGravity(Gravity.CENTER); root.addView(hint,new LinearLayout.LayoutParams(-1,dp(36)));
    }

    void loadApps() {
        Intent i = new Intent(Intent.ACTION_MAIN,null); i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = getPackageManager().queryIntentActivities(i,0);
        Collections.sort(list,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        for(ResolveInfo r:list) {
            String pkg=r.activityInfo.packageName;
            if(pkg.equals(getPackageName())) continue;
            apps.add(new AppInfo(r.loadLabel(getPackageManager()).toString(),pkg,r.loadIcon(getPackageManager()),r.activityInfo.name));
        }
        render("");
    }

    void render(String q) {
        grid.removeAllViews();
        ArrayList<AppInfo> shown = new ArrayList<>();
        String qq=q.toLowerCase(Locale.ROOT);
        for(AppInfo a:apps) if(qq.length()==0 || a.name.toLowerCase(Locale.ROOT).contains(qq)) shown.add(a);
        for(int i=0;i<shown.size();i+=4) {
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER);
            for(int j=i;j<i+4 && j<shown.size();j++) row.addView(appCard(shown.get(j)),new LinearLayout.LayoutParams(0,dp(112),1));
            grid.addView(row);
        }
    }

    View appCard(AppInfo a) {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setGravity(Gravity.CENTER);
        ImageView icon=new ImageView(this); icon.setImageDrawable(woolIcon(a.icon));
        box.addView(icon,new LinearLayout.LayoutParams(dp(66),dp(66)));
        TextView name=tv(a.name,11,Color.WHITE); name.setGravity(Gravity.CENTER); name.setSingleLine(true);
        box.addView(name,new LinearLayout.LayoutParams(-1,dp(30)));
        box.setOnClickListener(v->{ try { Intent in=new Intent(); in.setComponent(new ComponentName(a.pkg,a.cls)); in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(in); } catch(Exception e){} });
        return box;
    }

    Drawable woolIcon(Drawable original) {
        FrameLayout f=new FrameLayout(this);
        GradientDrawable wool=bg(Color.rgb(43,55,72),22);
        wool.setStroke(dp(2),Color.rgb(92,105,123));
        f.setBackground(wool);
        f.setElevation(dp(8));
        ImageView iv=new ImageView(this); iv.setImageDrawable(original); iv.setPadding(dp(9),dp(9),dp(9),dp(9));
        f.addView(iv,new FrameLayout.LayoutParams(-1,-1));
        // A translucent "fiber" ring gives the icon a soft textile/wool impression.
        TextView fiber=tv("✦",14,Color.argb(90,255,255,255)); fiber.setGravity(Gravity.TOP|Gravity.RIGHT);
        f.addView(fiber,new FrameLayout.LayoutParams(-1,-1));
        return f.getBackground()==null ? original : new FrameDrawable(f, this);
    }

    void updateTime() {
        new Handler().postDelayed(new Runnable(){public void run(){timeText.setText(new java.text.SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date())); updateTime();}},1000);
    }

    void refreshLabels() {
        if(lang.equals("ar")) { greeting.setText("أهلاً في ROHAT"); search.setHint("ابحث عن تطبيق..."); }
        else if(lang.equals("tr")) { greeting.setText("ROHAT'a hoş geldin"); search.setHint("Uygulama ara..."); }
        else { greeting.setText("Welcome to ROHAT"); search.setHint("Search apps..."); }
    }

    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}

    static class AppInfo { String name,pkg,cls; Drawable icon; AppInfo(String n,String p,Drawable i,String c){name=n;pkg=p;icon=i;cls=c;} }

    // Draw a View-backed wool tile as a Drawable without third-party libraries.
    static class FrameDrawable extends Drawable {
        FrameLayout v; MainActivity c; Bitmap bmp;
        FrameDrawable(FrameLayout vv,MainActivity cc){v=vv;c=cc; bmp=Bitmap.createBitmap(80,80,Bitmap.Config.ARGB_8888); Canvas x=new Canvas(bmp); v.layout(0,0,80,80); v.draw(x);}
        public void draw(Canvas canvas){canvas.drawBitmap(bmp,null,getBounds(),new Paint(Paint.ANTI_ALIAS_FLAG));}
        public void setAlpha(int a){} public void setColorFilter(android.graphics.ColorFilter f){} public int getOpacity(){return PixelFormat.TRANSLUCENT;}
    }
}