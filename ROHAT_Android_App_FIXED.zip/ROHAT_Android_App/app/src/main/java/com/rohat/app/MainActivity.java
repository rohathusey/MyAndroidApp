package com.rohat.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private TextView title(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 16, 12, 16);
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(35, 83, 145));
        b.setPadding(10, 8, 10, 8);
        return b;
    }

    private void base(String heading) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 30, 24, 24);
        root.setBackgroundColor(Color.rgb(10, 20, 35));

        TextView logo = title("ROHAT", 34);
        root.addView(logo, new LinearLayout.LayoutParams(-1, -2));

        TextView sub = title(heading, 20);
        root.addView(sub, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void showHome() {
        base("تطبيق روهات • ROHAT");

        TextView info = title("مرحباً بك\nWelcome • Hoş geldin", 18);
        info.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        root.addView(info, new LinearLayout.LayoutParams(-1, 0, 1));

        Button arabic = button("العربية");
        Button turkish = button("Türkçe");
        Button english = button("English");
        Button about = button("حول التطبيق");

        root.addView(arabic, new LinearLayout.LayoutParams(-1, -2));
        root.addView(turkish, new LinearLayout.LayoutParams(-1, -2));
        root.addView(english, new LinearLayout.LayoutParams(-1, -2));
        root.addView(about, new LinearLayout.LayoutParams(-1, -2));

        View.OnClickListener listener = v ->
            Toast.makeText(this, "ROHAT — جاهز للعمل", Toast.LENGTH_SHORT).show();
        arabic.setOnClickListener(listener);
        turkish.setOnClickListener(listener);
        english.setOnClickListener(listener);
        about.setOnClickListener(v -> showAbout());
    }

    private void showAbout() {
        base("حول ROHAT");
        TextView text = title(
            "نسخة Android قابلة للبناء عبر GitHub Actions\n\n" +
            "ROHAT APK\nVersion 1.0", 18);
        text.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
        root.addView(text, new LinearLayout.LayoutParams(-1, 0, 1));

        Button back = button("← العودة");
        root.addView(back, new LinearLayout.LayoutParams(-1, -2));
        back.setOnClickListener(v -> showHome());
    }
}
