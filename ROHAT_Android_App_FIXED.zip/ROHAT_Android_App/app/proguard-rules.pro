# ROHAT APK - no custom ProGuard rules required.
