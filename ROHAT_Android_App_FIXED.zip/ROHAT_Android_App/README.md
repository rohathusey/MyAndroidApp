# ROHAT Android App

مشروع Android نظيف ومبسّط ومجهز للبناء على GitHub Actions.

## البناء
يستخدم المشروع:
- Android Gradle Plugin 8.6.1
- Java 17
- compileSdk 35
- minSdk 23

تم تجنب `android-actions/setup-android@v3` في سير العمل حتى لا تتكرر مشكلة `sdkmanager` التي ظهرت في البناء السابق.

## GitHub Actions
الملف:
`.github/workflows/main.yml`

بعد رفع المشروع إلى GitHub:
1. افتح تبويب **Actions**.
2. شغّل **Build ROHAT APK**.
3. بعد النجاح ستجد ملف `ROHAT-debug-APK` في Artifacts.

## ملاحظة
المشروع لا يحتوي على مفاتيح توقيع أو بيانات سرية. ملف APK الناتج هو Debug APK.
